# About

The `SFXRay` dataset is used to research intelligent diagnosis of skeletal fluorosis. It constructed by Professor Yun Wu and his master student Hao Xu at Guizhou University. This dataset has published together with paper titled "Convolutional State Space Model with Multi-Window Cross-Scan to Advance the Automatic Diagnosis of Skeletal Fluorosis"  in journal of `Biomedical Signal Processing and Control`. 



# Dataset Description

Currently, the `SFXRay` dataset has only provided classification label. In next stage, we will provide segmentation label aimed to achieve more diversified analysis to skeletal fluorosis diagnosis.



# Dataset Usage Statement

This dataset is intended for scientific research use only and is prohibited for all uses other than scientific research. If you use the `SFXRay` dataset, you must cite the following two studies in the corresponding paper.

```
@article{xu2025107439,
  title={Convolutional state space model with multi-window cross-scan to advance the automated 	diagnosis of skeletal fluorosis},
  author={Xu, Hao and Wu, Yun and Xie, Rui and Xu, Jun and Wu, Junpeng and Wang, Rongpin and Tian, Youliang},
  journal={Biomedical Signal Processing and Control},
  volume={103},
  pages={107439},
  year={2025},
  publisher={Elsevier},
  doi={https://doi.org/10.1016/j.bspc.2024.107439},
}
@article{xu2024g2vit,
  title={G2ViT: Graph Neural Network-Guided Vision Transformer Enhanced Network for retinal vessel and coronary angiograph segmentation},
  author={Xu, Hao and Wu, Yun},
  journal={Neural Networks},
  volume={176},
  pages={106356},
  year={2024},
  publisher={Elsevier},
  doi={https://doi.org/10.1016/j.neunet.2024.106356}
}
```

